# Object-Detection-Lab
An basic object detector based on gradient features and sliding window classification, using class skeleton code (for Computational Photography course).
