Data uploaded on Google Drive:
https://drive.google.com/drive/folders/0B4MEkxcEs46xMmVIT01ScUpMTTg?usp=sharing
