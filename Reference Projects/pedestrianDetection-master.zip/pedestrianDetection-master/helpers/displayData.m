function displayData(x)

colormap(gray);
h = imagesc(x);
axis image off
drawnow;

end